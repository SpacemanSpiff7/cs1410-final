package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.Path2D;
import java.awt.geom.Path2D.Double;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import static asteroids.game.Constants.*;

/**
 * This class creates one dust particle with random direction and duration. Speed is constant.
 */
@SuppressWarnings("unused")
public class Dust extends Participant
{
    private Shape outline;

    private final static double DUST_SPEED = 0.7;

    public Dust (double x, double y)
    {
     // This will contain the outline
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(-.5, -.5);
        poly.lineTo(-.5, .5);
        poly.lineTo(.5, .5);
        poly.lineTo(.5, -.5);
        poly.closePath();
        // Save the outline
        outline = poly;
        
        setPosition(x,y);
        
        double direction = RANDOM.nextInt(361) * Math.PI / 180; 
        
        setVelocity(DUST_SPEED, direction);
        new ParticipantCountdownTimer(this, RANDOM.nextInt(800) + 700);
        
    }
   

    @Override
    protected Shape getOutline ()
    {
        
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

    /**
     * When dust duration is complete, dust expires.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        expire(this);

    }

}
