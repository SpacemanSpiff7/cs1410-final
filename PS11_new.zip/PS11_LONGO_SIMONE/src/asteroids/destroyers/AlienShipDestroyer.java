package asteroids.destroyers;

/**
 * Used to mark Participants that destroy Alien Ships.
 */
public interface AlienShipDestroyer
{
}
