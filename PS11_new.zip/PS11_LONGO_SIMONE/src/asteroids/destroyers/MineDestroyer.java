package asteroids.destroyers;

public interface MineDestroyer
{

}
