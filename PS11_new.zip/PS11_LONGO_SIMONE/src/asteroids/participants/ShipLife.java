package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

/**
 * Represents ships
 */
public class ShipLife extends Participant 
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    

    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public ShipLife (double x)
    {

        setPosition(x, 100);
        
        // Sets the ship with nose pointing up
        setRotation(-Math.PI/2);

        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();
        outline = poly;

       
    }

    
    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {
        super.move();
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub
        
    }

   
   
   
    
    
   
}
