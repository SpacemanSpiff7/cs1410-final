package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.AlienShipDestroyer;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.BulletDestroyer;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

/**
 * Represents bullets Must have area - (2 x 2) is a good dimension Must be centered at (0,0)
 */
public class Bullet extends Participant implements BulletDestroyer, AsteroidDestroyer, AlienShipDestroyer
{

    /** The outline of the bullet */
    private Shape outline;

    /** The game controller */
    @SuppressWarnings("unused")
    private Controller controller;

    /**
     * Creates a bullet with an outline, initial speed, and starting direction
     */
    public Bullet (double x, double y, double shipRotation, Controller controller)
    {

        // Create the bullet
        this.controller = controller;
        setPosition(x, y);
        setVelocity(BULLET_SPEED, shipRotation);

        // This will contain the outline
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(-1, -1);
        poly.lineTo(-1, 1);
        poly.lineTo(1, 1);
        poly.lineTo(1, -1);
        poly.closePath();

        // Save the outline
        outline = poly;

    }
    
    public void addTimer ()
    {
        new ParticipantCountdownTimer(this, BULLET_DURATION);
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * When an Bullet collides with an BulletDestroyer, it expires.
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof BulletDestroyer)
        {
            // Expire the bullet
            Participant.expire(this);

        }
    }

    /**
     * When BULLET_DURATION is complete, bullet expires.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        expire(this);

    }

}
