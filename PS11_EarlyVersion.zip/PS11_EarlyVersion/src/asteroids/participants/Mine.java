package asteroids.participants;

import static asteroids.game.Constants.RANDOM;
import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.MineDestroyer;
import asteroids.game.Controller;
import asteroids.game.Participant;

public class Mine extends Participant implements MineDestroyer, AsteroidDestroyer
{
    /** The outline of the ship */
    private Shape outline;

        
    public Mine (int x, int y, Controller controller)
    {
        
        setPosition(x,y);
        setRotation(2 * Math.PI * RANDOM.nextDouble());
        
        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(0, 0);
        poly.lineTo(100, 0);
        poly.lineTo(100, 100);
        poly.lineTo(0, 100);
        poly.closePath();
        outline = poly;
    }
    
   
    @Override
    protected Shape getOutline ()
    {
        
        return outline;
    }
    
    
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof MineDestroyer)
        {
            Participant.expire(this);
            
        }
        
    }

}
