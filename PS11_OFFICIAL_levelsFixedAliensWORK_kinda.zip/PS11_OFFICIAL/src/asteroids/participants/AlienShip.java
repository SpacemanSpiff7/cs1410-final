package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

/**
 * Represents ships
 */
public class AlienShip extends Participant
        implements AsteroidDestroyer, ShipDestroyer, AlienShipDestroyer, BulletDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    /**
     * AlienShip size
     */
    private int size;

    /**
     * Stores how many hits the alien ship has taken from bullets
     */
    private int damageCount;

    /**
     * Max number of bullet hits an alien ship can withstand
     */
    private int maxDamage;

    private double direction;

    private int shipSpeed;

    private boolean changeDirection = false;

    private int[] screenSides;

    private int side;

    private boolean shipAppear = false;

    private int startX;

    /**
     * Constructs a ship at the specified coordinates.
     */
    public AlienShip (int x, int y, int size, Controller controller)
    {

        this.size = size;
        this.shipSpeed = ALIENSHIP_SPEED[size];

        // Make sure size and variety are valid
        if (size < 0 || size > 1)
        {
            throw new IllegalArgumentException("Invalid alien ship size: " + size);
        }
        this.controller = controller;
        setPosition(x, y);
        setVelocity(shipSpeed, newDirection());

        outline = createAlienShipOutline();

        damageCount = 0;
        maxDamage = 1;

        // Schedule alien to appear after desired delay
        new ParticipantCountdownTimer(this, "appear", ALIEN_DELAY);
    }

    /**
     * Constructs a ship at random coordinates. Ship will initialize off screen on the left or right side, and at a
     * random y value. Will then move at a speed depending on it's size.
     */
    public AlienShip (int size, Controller controller)
    {
        screenSides = new int[] { 0, SIZE };
        double[] directionSide = new double[] { 0, Math.PI };
        side = RANDOM.nextInt(2);
        startX = screenSides[side];

        direction = directionSide[side];

        this.size = size;

        // Small ships travel at 5, medium at 3
        this.shipSpeed = ALIENSHIP_SPEED[size];

        // Make sure size and variety are valid
        if (size < 0 || size > 1)
        {
            throw new IllegalArgumentException("Invalid ship size: " + size);
        }
        this.controller = controller;

        createAlienShipOutline();

        damageCount = 0;
        // maxDamage = ALIENSHIP_DAMAGE[size];
        maxDamage = 1;

        // Set initial position of ship off screen
        this.setPosition(startX, -RANDOM.nextInt(SIZE));
        this.setVelocity(ALIENSHIP_SPEED[size], direction);
        new ParticipantCountdownTimer(this, "newdirection", 3000);

    }

    private double newDirection ()
    {

        return ALIENSHIP_DIRECTION[RANDOM.nextInt(ALIENSHIP_DIRECTION.length)];

    }

    private Shape createAlienShipOutline ()
    {
        // Path2D.Double alienShipOutline = new Path2D.Double();
        // alienShipOutline.moveTo(-5, -10);
        // alienShipOutline.lineTo(-5, -15);
        // alienShipOutline.lineTo(0, -17);
        // alienShipOutline.lineTo(5, -15);
        // alienShipOutline.lineTo(5, -10);
        // alienShipOutline.lineTo(-5, -10);
        // alienShipOutline.lineTo(-20, 0);
        // alienShipOutline.lineTo(20, 0);
        // alienShipOutline.lineTo(5, -10);
        // alienShipOutline.lineTo(20, 0);
        // alienShipOutline.lineTo(15, 10);
        // alienShipOutline.lineTo(-15, 10);
        // alienShipOutline.lineTo(-20, 0);
        // alienShipOutline.closePath();

        Path2D.Double alienShipOutline = new Path2D.Double();
        alienShipOutline.moveTo(20, 0);
        alienShipOutline.lineTo(10, 8);
        alienShipOutline.lineTo(-10, 8);
        alienShipOutline.lineTo(-20, 0);
        alienShipOutline.lineTo(20, 0);
        alienShipOutline.lineTo(-20, 0);
        alienShipOutline.lineTo(-10, -8);
        alienShipOutline.lineTo(10, -8);
        alienShipOutline.lineTo(-8, -8);
        alienShipOutline.lineTo(-6, -15);
        alienShipOutline.lineTo(6, -15);
        alienShipOutline.lineTo(8, -8);
        alienShipOutline.lineTo(10, -8);
        alienShipOutline.closePath();

        // Scale to the desired size
        double scale = ALIENSHIP_SCALE[size];
        alienShipOutline.transform(AffineTransform.getScaleInstance(scale, scale));

        outline = alienShipOutline;

        return outline;
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(0, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {

        super.move();

        if (changeDirection)
        {
            changeDirection = false;
            this.setDirection(newDirection());
            new ParticipantCountdownTimer(this, "newdirection", 3000);
        }

//        if (shipAppear && controller.getShip() != null)
//        {
//            shipAppear = false;
//            controller.addParticipant(new AlienShip(1, this.controller));
//            // Set initial position of ship off screen
//            this.setPosition(startX, -RANDOM.nextInt(SIZE));
//            this.setVelocity(ALIENSHIP_SPEED[size], direction);
//            new ParticipantCountdownTimer(this, "newdirection", 3000);
//        }

    }

    /**
     * When a Ship collides with an Asteroid or bullet, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof Bullet)
        {
            damageCount++;
            controller.addParticipant(new Dust(this.getX(), this.getY()));
            controller.addParticipant(new Dust(this.getX(), this.getY()));
        }
        if (p instanceof Asteroid || (p instanceof Bullet && damageCount == maxDamage))
        {
            controller.increaseScore(ALIENSHIP_SCORE[size]);

            // Expire the ship from the game
            Participant.expire(this);
            
            controller.alienShipDestroyed();

            // Display ship debris
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 10)); // TODO: check numbers
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 30));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 10));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 5));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 5));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 5));

//            if (controller.getAsteroidCount() != 0 && controller.getLives() > 0)
//            {
//                new ParticipantCountdownTimer(controller.getShip(), "respawn", 500);
//
//            }

        }
    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("newdirection"))
        {
            changeDirection = true;
        }

        
//        if (payload.equals("respawn"))
//        {
//            shipAppear = true;
//
//        }

    }

}
