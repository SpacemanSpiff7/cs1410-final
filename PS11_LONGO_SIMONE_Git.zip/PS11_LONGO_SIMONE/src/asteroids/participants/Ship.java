package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** The shape of the jet propulsion fire */
    private Shape fire;

    /** Game controller */
    private Controller controller;

    /** Is left turn key pressed? */
    private boolean shipLeftTurn;

    /** Is right turn key pressed? */
    private boolean shipRightTurn;

    /** Is UP key pressed? */
    private boolean shipAccelerate;

    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public Ship (int x, int y, double direction, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        setRotation(direction);

        outline = createShip();
        fire = createFlame();

        this.createFlame();

        // Schedule an acceleration in two seconds
        new ParticipantCountdownTimer(this, "move", 2000);
    }

    private Shape createShip ()
    {
        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();
        return poly;
    }

    /**
     * Creates the shape for propulsion flame
     */
    private Shape createFlame ()
    {
        Path2D.Double fire = new Path2D.Double();
        fire.moveTo(-14, -8);
        fire.lineTo(-14, 8);
        fire.lineTo(-20, 7);
        fire.lineTo(-15, 4);
        fire.lineTo(-25, 0);
        fire.lineTo(-15, -4);
        fire.lineTo(-20, -7);
        fire.closePath();
        return fire;
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {
        applyFriction(SHIP_FRICTION);
        super.move();

        turnLeft();
        turnRight();
        accelerate();
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        if (shipRightTurn)
        {
            rotate(Math.PI / 16);
        }
    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        if (shipLeftTurn)
        {
            rotate(-Math.PI / 16);
        }
    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {
        if (shipAccelerate)
        {
            accelerate(SHIP_ACCELERATION);
        }
    }

    public Shape getFire ()
    {
        return this.fire;
    }

    /**
     * When a Ship collides with a ShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {
            // Expire the ship from the game
            Participant.expire(this);
            
            // Display ship debris
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 43.7)); // TODO: check numbers
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 43.7));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 20));

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
        }
    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        // Give a burst of acceleration, then schedule another
        // burst for 200 msecs from now.
        if (payload.equals("move"))
        {
            accelerate();
            new ParticipantCountdownTimer(this, "move", 200);
        }
    }

    public void showFire ()
    {

        if (shipAccelerate)
        {
            ((Path2D) outline).append(fire, false);
        }
        if (!shipAccelerate)
        {
            outline = createShip();
        }
    }

    public boolean getRightTurn ()
    {
        return shipRightTurn;
    }

    public boolean getLeftTurn ()
    {
        return shipLeftTurn;
    }

    public void setRightTurn (boolean tf)
    {
        shipRightTurn = tf;
    }

    public void setLeftTurn (boolean tf)
    {
        shipLeftTurn = tf;
    }

    public void setAcceleration (boolean tf)
    {
        shipAccelerate = tf;
    }

    public boolean getAccelerationBool ()
    {
        return shipAccelerate;
    }
}
