package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.Path2D;
import java.awt.geom.Path2D.Double;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;
import static asteroids.game.Constants.*;

/**
 * This class creates one dust particle with random direction and duration. Speed is constant.
 */
@SuppressWarnings("unused")
public class ShipDebris extends Participant
{
    private Shape outline;

    private final static double DEBRIS_SPEED = 0.5;

    public ShipDebris (double x, double y, double lineLength)
    {
     // This will contain the outline
        Path2D.Double poly = new Path2D.Double();

        poly.moveTo(0, 0);
        poly.lineTo(lineLength*Math.cos(lineLength), lineLength*Math.sin(lineLength));
        
        // Save the outline
        outline = poly;
        
        setPosition(x,y);
        
        double direction = RANDOM.nextInt(361) * Math.PI / 180; 
        
        setVelocity(DEBRIS_SPEED, direction);
        new ParticipantCountdownTimer(this, RANDOM.nextInt(800) + 900);
        
    }
   

    @Override
    protected Shape getOutline ()
    {
        
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // TODO Auto-generated method stub

    }

    /**
     * When dust duration is complete, dust expires.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        expire(this);

    }

}
