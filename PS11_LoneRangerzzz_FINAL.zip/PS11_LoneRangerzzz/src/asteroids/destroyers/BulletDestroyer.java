package asteroids.destroyers;


/**
 * Used to mark Participants that destroy Bullets.
 */
public interface BulletDestroyer
{

}
