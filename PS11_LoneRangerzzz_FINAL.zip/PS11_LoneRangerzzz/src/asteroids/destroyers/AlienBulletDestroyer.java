package asteroids.destroyers;

public interface AlienBulletDestroyer
{

}
