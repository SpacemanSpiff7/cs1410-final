package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;


/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer, AlienShipDestroyer, AlienBulletDestroyer
{
    /** The outline of the ship */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    /** Is left turn key pressed? */
    private boolean shipLeftTurn;

    /** Is right turn key pressed? */
    private boolean shipRightTurn;

    /** Is UP key pressed? */
    private boolean shipAccelerate;

    /** Is SPACE key pressed? */
    private boolean shipShoot;

    /** Should the thruster flame show. Triggers with 'shipAccelerate' */
    public boolean thrusterOn;

    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public Ship (int x, int y, double direction, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        setRotation(direction);

        outline = createShip();

        
    }

    private Shape createShip ()
    {
        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();
        return poly;
    }

    /**
     * Creates the shape for propulsion flame
     */
    private Shape createShipAndFlame ()
    {
        Path2D.Double fire = new Path2D.Double();
        // Draws ship
        fire.moveTo(21, 0);
        fire.lineTo(-21, 12);
        fire.lineTo(-14, 10);
        fire.lineTo(-14, -10);
        fire.lineTo(-21, -12);
        fire.closePath();

        // Draws flame
        fire.moveTo(-14, -8);
        fire.lineTo(-14, 8);
        fire.lineTo(-20, 7);
        fire.lineTo(-15, 4);
        fire.lineTo(-25, 0);
        fire.lineTo(-15, -4);
        fire.lineTo(-20, -7);
        fire.closePath();
        return fire;
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {
        applyFriction(SHIP_FRICTION);
        super.move();

        turnLeft();
        turnRight();
        accelerate();
        shootBullets();

        if (shipAccelerate)
        {
            showThruster();
        }
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        if (shipRightTurn)
        {
            rotate(Math.PI / 16);
        }
    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        if (shipLeftTurn)
        {
            rotate(-Math.PI / 16);
        }
    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {
        if (shipAccelerate)
        {
            accelerate(SHIP_ACCELERATION);
        }
    }
    
    public void shootBullets ()
    {
        if (shipShoot)
        {
            if (controller.underBulletMax())
            {
                Bullet shotFired = new Bullet(this.getXNose(), this.getYNose(), this.getRotation(), this.controller);
                controller.addParticipant(shotFired);
                shotFired.addTimer();
                controller.shootSound();
            }
        }
    }

    /**
     * When a Ship collides with a ShipDestroyer, it expires
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof ShipDestroyer)
        {
            controller.shipExplosionSound();
            
            // Expire the ship from the game
            Participant.expire(this);

            // Display ship debris
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 43.7));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 43.7));
            controller.addParticipant(new ShipDebris(this.getX(), this.getY(), 20));

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
        }
    }

    
    /**
     * This method is invoked when a ParticipantCountdownTimer completes its countdown.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        
        
        
    }

    
    
    public void showThruster ()
    {

        // Toggle for flicker effect
        toggle(thrusterOn);
        if (thrusterOn)
        {
            outline = createShipAndFlame();
        }
        if (!thrusterOn)
        {
            outline = createShip();
        }

    }

    /**
     * If true, set false and vice versa
     * @param thrusterOn2
     */
    private void toggle (boolean thrusterOn2)
    {
        if (thrusterOn2)
        {
            thrusterOn = false;
        }
        else
        {
            thrusterOn = true;
        }

    }

    public boolean getRightTurn ()
    {
        return shipRightTurn;
    }

    public boolean getLeftTurn ()
    {
        return shipLeftTurn;
    }

    public void setRightTurn (boolean tf)
    {
        shipRightTurn = tf;
    }

    public void setLeftTurn (boolean tf)
    {
        shipLeftTurn = tf;
    }

    public void setAcceleration (boolean tf)
    {
        shipAccelerate = tf;
    }

    public boolean getAccelerationBool ()
    {
        return shipAccelerate;
    }

    public void setShipShoot (boolean tf)
    {
        shipShoot = tf;
    }

    public boolean getShipShoot ()
    {
        return shipShoot;
    }
}
